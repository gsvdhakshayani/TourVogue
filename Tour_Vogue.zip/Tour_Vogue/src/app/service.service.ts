import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private isUserLogged: any;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = true;
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = true;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
   getCountriesList(): any {
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }
   getUser(loginId : any, password : any): any {
    return this.httpClient.get('RestAPI/webapi/myresource/getUserByUserPass/' + loginId + '/' + password);
   }
   getEmpById(empId: any) {
    return this.httpClient.get('RestAPI/webapi/myresource/getEmployeeById/' + empId);
   }
   registerUser(user: any) {
    return this.httpClient.post('RestAPI/webapi/myresource/registerUser/',  user);
   }
   validateUser(user : any) {
    return this.httpClient.post('RestAPI/webapi/myresource/getUserByUserPass/', user);
   }
   deleteEmp(employee: any) {
    return this.httpClient.delete('RestAPI/webapi/myresource/deleteEmp/' + employee.empId);
   }

   updateEmp(editObject: any) {
    return this.httpClient.put('RESTAPI/webapi/myresource/updateEmp', editObject);
   }

   getAllDepartments(): any {
    return this.httpClient.get('RestAPI/webapi/myresource/getDepartments');
   }
   

}

