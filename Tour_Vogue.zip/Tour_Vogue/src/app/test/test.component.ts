import { Component, OnInit } from '@angular/core';
import {NgStyle} from '@angular/common'
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  age : number;
  name : string;
  salary : number;
  isEmployee : boolean;
  hobbies : any;
  address : any;
  message : string;

  constructor() { 
    this.age = 25;
    this.name = 'SACHIN';
    this.salary = 9999.99;
    this.isEmployee = true;
    this.hobbies = ['Singing', 'Chatting', 'Gaming', 'Sleeping', 'Eating'];
    this.address = {doorNo : '10-10/A', street : 'Vishnu', city : 'BVM'}
  }

  ngOnInit() {
  }
  showMessage() :void {
    alert('show method is called.....');
    console.log(this.message);
  }
  

}
