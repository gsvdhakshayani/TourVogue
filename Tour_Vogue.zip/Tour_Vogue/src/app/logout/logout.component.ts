import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private serviceService : ServiceService, private router :Router) { }

  ngOnInit(): void {
  }
  
  userLogout() : void {
      this.serviceService.setUserLoggedOut();
      this.router.navigate(['login']);
  }  

}
